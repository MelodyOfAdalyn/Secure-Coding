// Exceptions.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
// CustomException class that extends from std::exception
struct CustomException : public std::exception
{
    //if the const throw() is called, return a message 
    virtual const char* what() const throw()
    {
        return "Custom exception has a message!";
    }
};


bool do_even_more_custom_application_logic()
{   //Throw any standard exception 
    //Will be caught in main()
    throw std::bad_exception();
    
    std::cout << "Running Even More Custom Application Logic." << std::endl;
    
    return true;

}
void do_custom_application_logic()
{
  std::cout << "Running Custom Application Logic." << std::endl;

  try //add try/catch to test for errors during execution
  {
      if (do_even_more_custom_application_logic())
      {
          std::cout << "Even More Custom Application Logic Succeeded." << std::endl;
      }
  }
  catch (const std::exception& exception) //generate exception message if exception is caught, continue processing
  {
      std::cerr << "Exception message: " << exception.what() << std::endl;
  }
  //Throw a custom exception derived from std::exception
  //No try/catch implemented here because it is caught in main()
  throw CustomException();
  std::cout << "Leaving Custom Application Logic." << std::endl;

}

float divide(float num, float den)
{ //Throw an exception to deal with divide by zero errors using a standard C++ defined exception
    //den cannot be zero, so a runtime error message will display
    if (den == 0) 
    {
        throw std::runtime_error("Cannot divide by zero. Invalid.");
    }
    return (num / den);
}

void do_division() noexcept
{
  //  TODO: create an exception handler to capture ONLY the exception thrown
  //  by divide.

  float numerator = 10.0f;
  float denominator = 0;
  //Try dividing the values
  try
  {
  auto result = divide(numerator, denominator);
  std::cout << "divide(" << numerator << ", " << denominator << ") = " << result << std::endl;
  }
  //catch exception thrown by divide
  catch (const std::exception& exception)
  {
      std::cerr << "Exception message: " << exception.what() << std::endl;
  }
}

int main()
{
    //Add try/catch within main 
    try
    {
  std::cout << "Exceptions Tests!" << std::endl;
  
  do_division();
  do_custom_application_logic();
}
    //Wraps the whole main function, and displays a message to the console.
    //Implement Custom Exception 
    catch (const CustomException exception)
    {
        std::cerr << "Exception message: " << exception.what() << std::endl;
    }
    //std::exception
    catch (const std::exception& exception)
    {
        std::cerr << "Exception message: " << exception.what() << std::endl;
    }
    //uncaught exception
    catch (...)
    {
    }
}

// Run program: Ctrl + F5 or Debug > Start Without Debugging menu
// Debug program: F5 or Debug > Start Debugging menu
